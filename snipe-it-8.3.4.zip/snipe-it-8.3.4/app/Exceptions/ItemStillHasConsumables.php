<?php

namespace App\Exceptions;

use Exception;

class ItemStillHasConsumables extends ItemStillHasChildren
{
    //
}
