<?php

namespace App\Exceptions;

use Exception;

class ItemStillHasAssetModels extends ItemStillHasChildren
{
    //
}
