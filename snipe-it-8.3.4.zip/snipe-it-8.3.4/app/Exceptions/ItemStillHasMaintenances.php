<?php

namespace App\Exceptions;

use Exception;

class ItemStillHasMaintenances extends ItemStillHasChildren
{
    //
}
