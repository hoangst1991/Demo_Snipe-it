<?php

namespace App\Exceptions;

use Exception;

class ItemStillHasAssets extends ItemStillHasChildren
{
}
