<?php

namespace App\Exceptions;

use Exception;

class ItemStillHasAccessories extends ItemStillHasChildren
{
    //
}
