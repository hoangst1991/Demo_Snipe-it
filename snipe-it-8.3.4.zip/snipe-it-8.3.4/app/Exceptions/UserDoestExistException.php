<?php

namespace App\Exceptions;

use Exception;

class UserDoestExistException extends Exception
{

}
