<?php

namespace App\Exceptions;

use Exception;

class ItemStillHasLicenses extends ItemStillHasChildren
{
    //
}
