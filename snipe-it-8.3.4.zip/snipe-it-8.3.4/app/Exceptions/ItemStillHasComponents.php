<?php

namespace App\Exceptions;

use Exception;

class ItemStillHasComponents extends ItemStillHasChildren
{
    //
}
